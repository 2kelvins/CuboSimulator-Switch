LAURA ADVENTURE - WATER ART REFERENCE PACK

Four cropped horizontal water strips from the approved concept image.
These are visual assets, NOT verified seamless tiles or tested animation.
Frames: 1920x70 PNG, RGB.
Source concept image included for comparison.
To use in-game: create seamless tile edges, choose water surface Y, animate frame changes, and preserve collision logic.
